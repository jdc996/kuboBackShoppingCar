module.exports = function configSetup() {
    // istanbul ignore next
    return {
      'db': {
        'connectionString': process.env.MONGO_URL || 'mongodb+srv://kubo-admin:UINBn3QfK0ZCD3dh@production-kubo.dmvre.mongodb.net/kubo-shopping-car-production?retryWrites=true&w=majority'
      },
    };
  };